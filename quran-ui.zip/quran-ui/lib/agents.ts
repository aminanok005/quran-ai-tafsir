import type { AgentId } from "./types";

// Display names only. No scholarly claims or biographical data live in the UI.
export const AGENTS: { id: AgentId; name: string }[] = [
  { id: "ibn_kathir", name: "Ibn Kathir" },
  { id: "al_tabari", name: "Al-Tabari" },
  { id: "al_qurtubi", name: "Al-Qurtubi" },
  { id: "ibn_ashur", name: "Ibn Ashur" },
  { id: "al_saadi", name: "Al-Sa'di" },
  { id: "al_zuhayli", name: "Al-Zuhayli" },
];
