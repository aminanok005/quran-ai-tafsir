// Shared UI contracts. All religious content arrives via API; nothing is hardcoded in the UI.

export type EvidenceLevel =
  | "VERIFIED"
  | "SOURCE_ATTRIBUTED"
  | "SCHOLARLY_DIFFERENCE"
  | "UNVERIFIED"
  | "AI_SYNTHESIS";

export type AgentId =
  | "ibn_kathir"
  | "al_tabari"
  | "al_qurtubi"
  | "ibn_ashur"
  | "al_saadi"
  | "al_zuhayli";

export interface Ayah {
  surah: number;
  ayah: number;
  textUthmani: string; // from Quran.Foundation API
  translationTh?: string | null; // certified translation; null => show placeholder state
}

export interface SourceRef {
  book: string;
  volume?: number | null;
  page?: number | null;
}

export interface TafsirResult {
  agent: AgentId;
  evidence: EvidenceLevel;
  source?: SourceRef | null;
  excerptAr?: string | null; // original Arabic, preserved verbatim
  summaryTh?: string | null; // AI-SYNTHESIS, labelled separately
}

export const INSUFFICIENT_MESSAGE =
  "The available classical sources are insufficient to establish this specific detail.";
