import type { Config } from "tailwindcss";

// Design tokens — Design.md §3.1. Extend only; never replace Tailwind defaults.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          900: "#073B32",
          800: "#0E5E4F",
          700: "#147B68",
          100: "#E6F4F1",
        },
        accent: {
          500: "#C9A227",
          700: "#7A5F00", // text-safe gold on light surfaces
          100: "#FEF9E7",
          200: "#EBDDA0",
        },
        surface: {
          DEFAULT: "#F5F7F6",
          card: "#FFFFFF",
          border: "#DCE5E2",
          sunken: "#FAFBFB",
        },
        ink: {
          DEFAULT: "#1E293B",
          muted: "#475569",
          dark: "#0F172A",
        },
        evidence: {
          verified: { bg: "#E6F4F1", fg: "#0E5E4F" },
          source: { bg: "#E0EEFF", fg: "#1D4ED8" },
          difference: { bg: "#FEF3C7", fg: "#92400E" },
          unverified: { bg: "#E2E8F0", fg: "#334155" },
          ai: { bg: "#EDE9FE", fg: "#5B21B6" },
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "var(--font-thai)", "system-ui", "sans-serif"],
        arabic: ["var(--font-arabic)", "serif"],
      },
      width: { left: "260px", right: "420px" },
      boxShadow: {
        float: "0 30px 80px rgba(7,59,50,.14)",
      },
      borderRadius: { card: "16px" },
      lineHeight: { quran: "2.2" },
    },
  },
  plugins: [],
};

export default config;
