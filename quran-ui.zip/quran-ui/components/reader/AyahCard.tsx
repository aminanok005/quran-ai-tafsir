import type { Ayah } from "@/lib/types";
import { EvidenceBadge } from "@/components/ui/EvidenceBadge";

interface Props {
  ayah: Ayah;
  selected: boolean;
  onSelect: (ayah: number) => void;
}

export function AyahCard({ ayah, selected, onSelect }: Props) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      onClick={() => onSelect(ayah.ayah)}
      className={`flex w-full flex-col items-start gap-1.5 rounded-card border p-5 text-left transition-colors ${
        selected ? "border-primary-800 bg-primary-100" : "border-surface-border bg-surface-card hover:bg-surface-sunken"
      }`}
    >
      <span className="flex w-full items-center justify-between">
        <span className="text-xs font-bold tracking-wider text-ink-muted">
          {ayah.surah}:{ayah.ayah}
        </span>
        {selected && (
          <span className="sr-only">เลือกแล้ว</span>
        )}
        {selected && <EvidenceBadge level="VERIFIED" />}
      </span>
      <span dir="rtl" lang="ar" className="quran-text w-full text-right">
        {ayah.textUthmani}
      </span>
      <span className="text-sm text-ink-muted">
        {ayah.translationTh ?? "ยังไม่มีคำแปลไทยจากแหล่งที่ได้รับรอง"}
      </span>
    </button>
  );
}
