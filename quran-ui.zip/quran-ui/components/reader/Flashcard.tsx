"use client";

import { useState } from "react";
import { EvidenceBadge } from "@/components/ui/EvidenceBadge";

interface Props {
  frontAr: string;
  back?: string | null; // AI-generated; absent => placeholder
}

export function Flashcard({ frontAr, back }: Props) {
  const [flipped, setFlipped] = useState(false);
  return (
    <div className="flex flex-col gap-3.5">
      <div className="flex items-center justify-between">
        <span className="text-[15px] font-bold">แฟลชการ์ด</span>
        <EvidenceBadge level="AI_SYNTHESIS" />
      </div>
      <button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        aria-label="พลิกการ์ด"
        className={`flex min-h-[200px] w-full items-center justify-center rounded-[18px] border p-6 transition-colors ${
          flipped ? "border-accent-200 bg-accent-100" : "border-primary-800 bg-primary-800"
        }`}
      >
        {flipped ? (
          <span className="w-full text-left text-sm text-ink">{back ?? "ยังไม่มีเนื้อหาด้านหลังการ์ด"}</span>
        ) : (
          <span dir="rtl" lang="ar" className="font-arabic text-[44px] leading-quran text-white">
            {frontAr}
          </span>
        )}
      </button>
      <div className="text-center text-[13px] text-ink-muted">แตะการ์ดเพื่อพลิก</div>
    </div>
  );
}
