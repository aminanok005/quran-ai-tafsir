import { AGENTS } from "@/lib/agents";
import { INSUFFICIENT_MESSAGE, type TafsirResult, type AgentId } from "@/lib/types";
import { EvidenceBadge } from "@/components/ui/EvidenceBadge";

interface Props {
  agent: AgentId;
  result: TafsirResult | null | undefined;
}

function referenceLine(result: TafsirResult): string {
  const s = result.source;
  if (!s) return "Reference location unavailable";
  const parts = [s.book];
  if (s.volume != null && s.page != null) parts.push(`เล่ม ${s.volume} หน้า ${s.page}`);
  else parts.push("Reference location unavailable");
  return parts.join(" · ");
}

export function TafsirPanel({ agent, result }: Props) {
  const name = AGENTS.find((a) => a.id === agent)?.name ?? agent;
  // No source (or no result) => never render invented content.
  const insufficient = !result || !result.source || result.evidence === "UNVERIFIED";

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[15px] font-bold">{name} Tafsir Agent</span>
        <EvidenceBadge level={insufficient ? "UNVERIFIED" : result.evidence} />
      </div>

      {insufficient ? (
        <div className="flex flex-col gap-2.5 rounded-card border border-slate-300 bg-slate-50 p-5" role="status">
          <div className="text-[15px] font-bold">ยังไม่มีหลักฐานเพียงพอ</div>
          <div className="text-sm text-slate-700">{INSUFFICIENT_MESSAGE}</div>
        </div>
      ) : (
        <>
          <div className="flex flex-col gap-3 rounded-card border border-surface-border p-4">
            <div className="text-sm">
              {name} Tafsir Agent: ตามหนังสือ {referenceLine(result)}
            </div>
            {result.excerptAr && (
              <div dir="rtl" lang="ar" className="rounded-xl bg-surface p-3 font-arabic text-xl leading-quran">
                {result.excerptAr}
              </div>
            )}
          </div>
          {result.summaryTh && (
            <div className="flex flex-col gap-2.5 rounded-card border border-dashed border-violet-300 bg-violet-50 p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">สรุปเพื่อการเรียนรู้</span>
                <EvidenceBadge level="AI_SYNTHESIS" />
              </div>
              <p className="m-0 text-sm text-ink">{result.summaryTh}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
