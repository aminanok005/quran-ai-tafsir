import { AGENTS } from "@/lib/agents";
import type { AgentId } from "@/lib/types";

interface Props {
  active: AgentId;
  onChange: (id: AgentId) => void;
}

export function AgentChips({ active, onChange }: Props) {
  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label="เลือกเอเจนต์ตัฟซีร">
      {AGENTS.map((a) => {
        const on = a.id === active;
        return (
          <button
            key={a.id}
            type="button"
            aria-pressed={on}
            onClick={() => onChange(a.id)}
            className={`min-h-[44px] rounded-full border px-3.5 text-[13px] font-semibold transition-colors ${
              on
                ? "border-primary-800 bg-primary-800 text-white"
                : "border-slate-300 bg-white text-slate-700 hover:bg-primary-100"
            }`}
          >
            {a.name}
          </button>
        );
      })}
    </div>
  );
}
