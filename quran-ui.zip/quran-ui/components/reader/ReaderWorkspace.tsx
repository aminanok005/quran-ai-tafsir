"use client";

import { useState } from "react";
import type { AgentId, Ayah, TafsirResult } from "@/lib/types";
import { AyahCard } from "./AyahCard";
import { AgentChips } from "./AgentChips";
import { TafsirPanel } from "./TafsirPanel";
import { Flashcard } from "./Flashcard";

type Tab = "tafsir" | "compare" | "review";
const TABS: { id: Tab; label: string }[] = [
  { id: "tafsir", label: "ตัฟซีร" },
  { id: "compare", label: "เทียบทัศนะ" },
  { id: "review", label: "ทบทวน" },
];

interface Props {
  surahTitle: string;
  ayahs: Ayah[];
  /** results for the currently selected ayah, keyed by agent. Provided by API. */
  tafsirFor: (ayah: number) => Partial<Record<AgentId, TafsirResult>>;
  onSelectAyah?: (ayah: number) => void;
}

export function ReaderWorkspace({ surahTitle, ayahs, tafsirFor, onSelectAyah }: Props) {
  const [ayahNo, setAyahNo] = useState<number | null>(ayahs[0]?.ayah ?? null);
  const [agent, setAgent] = useState<AgentId>("ibn_kathir");
  const [tab, setTab] = useState<Tab>("tafsir");

  const selected = ayahs.find((a) => a.ayah === ayahNo) ?? null;
  const results = ayahNo != null ? tafsirFor(ayahNo) : {};

  function select(n: number) {
    setAyahNo(n);
    onSelectAyah?.(n);
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="flex min-h-16 items-center justify-between border-b border-surface-border bg-white px-5">
        <span className="font-extrabold text-primary-900">QURAN AI</span>
      </header>

      <div className="flex flex-1 flex-wrap">
        <aside className="w-full shrink-0 border-r border-surface-border bg-white p-4 lg:w-left">
          <div className="px-3 py-1 text-[11px] font-bold tracking-widest text-ink-muted">สูเราะฮ์</div>
          <div className="rounded-xl bg-primary-100 px-3 py-2.5 text-sm font-bold text-primary-900">{surahTitle}</div>
        </aside>

        <main className="flex min-w-0 flex-[1_1_420px] flex-col gap-4 p-8">
          {ayahs.length === 0 ? (
            <div className="rounded-card border border-surface-border bg-white p-6 text-sm text-ink-muted" role="status">
              กำลังโหลดอายะฮ์จาก Quran.Foundation API
            </div>
          ) : (
            ayahs.map((a) => (
              <AyahCard key={`${a.surah}:${a.ayah}`} ayah={a} selected={a.ayah === ayahNo} onSelect={select} />
            ))
          )}
        </main>

        <aside className="w-full shrink-0 border-l border-surface-border bg-white lg:w-right">
          <div className="flex gap-1 border-b border-surface-border px-4 pt-3" role="tablist">
            {TABS.map((t) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={tab === t.id}
                onClick={() => setTab(t.id)}
                className={`min-h-[44px] border-b-[3px] px-4 text-sm ${
                  tab === t.id ? "border-accent-500 font-bold text-primary-900" : "border-transparent text-ink-muted"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex flex-col gap-4 p-4">
            {tab === "tafsir" && (
              <>
                <div className="text-[13px] text-ink-muted">
                  {selected ? `บริบทที่ล็อกไว้: ${selected.surah}:${selected.ayah}` : "ยังไม่ได้เลือกอายะฮ์"}
                </div>
                <AgentChips active={agent} onChange={setAgent} />
                <TafsirPanel agent={agent} result={results[agent]} />
              </>
            )}
            {tab === "compare" && (
              <div className="text-sm text-ink-muted">เมทริกซ์เปรียบเทียบทัศนะจะแสดงเมื่อมีผลจากอย่างน้อยสองเอเจนต์</div>
            )}
            {tab === "review" && selected && <Flashcard frontAr={selected.textUthmani} />}
          </div>
        </aside>
      </div>
    </div>
  );
}
