import type { EvidenceLevel } from "@/lib/types";

const STYLE: Record<EvidenceLevel, { cls: string; label: string }> = {
  VERIFIED: { cls: "bg-evidence-verified-bg text-evidence-verified-fg", label: "VERIFIED" },
  SOURCE_ATTRIBUTED: { cls: "bg-evidence-source-bg text-evidence-source-fg", label: "SOURCE-ATTRIBUTED" },
  SCHOLARLY_DIFFERENCE: { cls: "bg-evidence-difference-bg text-evidence-difference-fg", label: "SCHOLARLY-DIFFERENCE" },
  UNVERIFIED: { cls: "bg-evidence-unverified-bg text-evidence-unverified-fg", label: "UNVERIFIED" },
  AI_SYNTHESIS: { cls: "bg-evidence-ai-bg text-evidence-ai-fg", label: "AI-SYNTHESIS" },
};

export function EvidenceBadge({ level }: { level: EvidenceLevel }) {
  const s = STYLE[level];
  return (
    <span
      className={`inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-bold tracking-wide ${s.cls}`}
    >
      {s.label}
    </span>
  );
}
