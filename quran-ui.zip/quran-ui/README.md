# QURAN AI web UI (Next.js 14 + Tailwind)

Design tokens: `tailwind.config.ts` (Design.md §3.1). Components: `components/`.
Copy into `apps/web/`, then `npm install && npm run typecheck && npm run build`.

Rules baked in:
- No Quran text, translation or tafsir in code. All content arrives via props/API.
- `TafsirPanel` shows the standard "insufficient sources" state when there is no source or evidence is UNVERIFIED.
- Missing volume/page renders "Reference location unavailable".
- AI summaries always carry the AI-SYNTHESIS badge.

Wire-up TODO: Quran.Foundation client -> `app/page.tsx`; tafsir API -> `tafsirFor`.
