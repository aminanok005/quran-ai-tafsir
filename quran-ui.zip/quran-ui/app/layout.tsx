import type { Metadata } from "next";
import { Amiri_Quran, Noto_Sans_Thai, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const sans = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const thai = Noto_Sans_Thai({ subsets: ["thai"], variable: "--font-thai", display: "swap" });
const arabic = Amiri_Quran({ subsets: ["arabic"], weight: "400", variable: "--font-arabic", display: "swap" });

export const metadata: Metadata = {
  title: "QURAN AI",
  description: "ศึกษาอัลกุรอานและตัฟซีรอย่างมีหลักฐาน",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="th" className={`${sans.variable} ${thai.variable} ${arabic.variable}`}>
      <body>{children}</body>
    </html>
  );
}
