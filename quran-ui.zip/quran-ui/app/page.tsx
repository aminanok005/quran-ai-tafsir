import { ReaderWorkspace } from "@/components/reader/ReaderWorkspace";

// TODO(API): replace the empty list with data from the Quran.Foundation client.
// Intentionally no hardcoded Quran text, translations or tafsir here.
export default function Page() {
  return <ReaderWorkspace surahTitle="อัลฟาติหะฮ์" ayahs={[]} tafsirFor={() => ({})} />;
}
